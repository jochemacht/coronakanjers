# coronakanjers
#
karmabit te koop van michiel
Ragnarok is een goede naam
haters be hatin 
